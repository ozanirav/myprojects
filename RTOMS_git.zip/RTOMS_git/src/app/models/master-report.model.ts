export class Product {
    public company_id : number;
    public company_name : string;
    public address_line1 : string;
    public address_line2 : string;
    public country_name: string;
    public state_name: string;
    public pincode: number;
    public company_type: string;
    public is_active : string;
}