export const environment = {
  production: true,
  baseUrl:'http://parth.samudratech.in:81/api/company/',
  baseUrlDropDown:'http://parth.samudratech.in:81/api/DropDownList/',
};
