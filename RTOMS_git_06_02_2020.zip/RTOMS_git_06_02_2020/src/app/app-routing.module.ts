import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MasterReportComponent } from './master-report/master-report.component';

import {  SamplePageComponent } from './sample-page/sample-page.component'


const routes: Routes = [
  { path: '', component: MasterReportComponent},
  { path: 'samplepage', component: SamplePageComponent, pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
