import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MenuComponent } from './menu/menu.component';
import { MasterReportComponent } from './master-report/master-report.component';
import { HttpClient, HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';

import { GridEditFormComponent } from './master-report/edit-form.component';
import { EditService } from './services/master-report.service';

// Notify
import { NotifierModule } from "angular-notifier";
import { customNotifierOptions, UtilsModule } from './utils/utils';
import { SamplePageComponent } from './sample-page/sample-page.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    MasterReportComponent,
    GridEditFormComponent,
    SamplePageComponent,
  ],
  imports: [
    HttpClientModule,
    HttpClientJsonpModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    GridModule,
    DialogModule,
    DropDownsModule,
    NotifierModule,
    NotifierModule.withConfig(customNotifierOptions),
  ],
  providers: [
    {
        deps: [HttpClient],
        provide: EditService,
        useFactory: (jsonp: HttpClient) => () => new EditService(jsonp)
    },
    UtilsModule
],
  bootstrap: [AppComponent]
})
export class AppModule { }
