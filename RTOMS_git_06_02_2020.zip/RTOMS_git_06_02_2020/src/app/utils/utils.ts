import { NgModule, Inject, Injectable } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotifierOptions, NotifierService } from 'angular-notifier';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class UtilsModule {

  public SUCCESS_TAG = 'success';
  public ERROR_TAG = 'error';

  // public appCom:AppComponent;
  
  private notifier: NotifierService;

  constructor(notifierService: NotifierService) {
    this.notifier = notifierService;
    // this.appCom = _appCom;
  } 

  public _loaderShow = true;

  // hideLoader(){
  //   this.appCom.toggleLoader(false);
  // }

  // showLoader(){
  //   this.appCom.toggleLoader(true);
  // }

  public notify(type = this.ERROR_TAG, header = "", message = "") {
      debugger;;
    this.notifier.notify(type, header);
  }

}
export const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: 'right',
      distance: 12
    },
    vertical: {
      position: 'top',
      distance: 12,
      gap: 10
    }
  },
  theme: 'material',
  behaviour: {
    autoHide: 3000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};