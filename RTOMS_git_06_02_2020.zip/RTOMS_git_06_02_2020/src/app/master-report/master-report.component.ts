import { Observable } from 'rxjs';
import { Component, OnInit, Inject } from '@angular/core';

import { GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';

import { CompanyListModel, StateModel } from '../models/master-report.model';
import { EditService } from '../services/master-report.service';

import { map } from 'rxjs/operators';

import { UtilsModule } from '../utils/utils';


@Component({
  selector: 'app-master-report',
  templateUrl: './master-report.component.html',
  styleUrls: ['./master-report.component.scss']
})

export class MasterReportComponent implements OnInit {
  public view: Observable<GridDataResult>;
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10
    };

    public editDataItem: CompanyListModel;
    public isNew: boolean;
    private editService: EditService;

    public companys: CompanyListModel[];

    companyId: any;
    company_update_data: any;

    //stateList: Array<StateModel> = [];
    //selectedSateValue: StateModel = { stateId: 'Select product...', stateName: null };

    constructor(@Inject(EditService) editServiceFactory: any, private utilModule: UtilsModule) {
        this.editService = editServiceFactory();
        this.getCompanyListData();
    }

    public ngOnInit(): void {
       // this.view = this.editService.pipe(map(data => process(data, this.gridState)));
        this.editService.read();
        this.getCompanyListData();
    }

    public getCompanyListData() {
        //let company = new CompanyListModel();
        //role.flag = 'fetch';
        let res = this.editService.getCompanyListService();
        res.subscribe((resp: any) => {
            this.companys = resp.Table1;
            debugger;;
            this.companys = [];
            resp.Table1.map(item => 
                {
                    this.companys.push({
                    company_id: item.company_id,
                    company_name: item.company_name,
                    address_line1: item.address_line1,
                    address_line2: item.address_line2,
                    country_name: item.country_name,
                    state_name: item.state_name,
                    pincode: item.pincode,
                    company_type: item.company_type,
                    is_active: (item.is_active == "No") ? false : true
                })
            });
            this.companys.sort(function(a, b){
                return a.company_id - b.company_id;
              });
        })
    }
    
    public onStateChange(state: State) {
        this.gridState = state;
        this.editService.read();
    }

    public addHandler() {
        debugger
        this.editDataItem = new CompanyListModel();
        this.isNew = true;
    }

    public editHandler({dataItem}) {
        this.editDataItem = dataItem;
        this.isNew = false;
    }

    public cancelHandler() {
        this.editDataItem = undefined;
    }

    public saveHandler(date) {
        debugger;;
        //this.editService.save(companyListModel, this.isNew);
        let res = this.editService.updateCompany(date);
        res.subscribe((resp: any) => {
            debugger;;
            if (resp.Table[0].is_successful == 1) {
                this.utilModule.notify(this.utilModule.SUCCESS_TAG, resp.Table[0].message);
            } else {
                this.utilModule.notify(this.utilModule.ERROR_TAG, resp.Table[0].message);
            }
           
           this.getCompanyListData();
        })
        
        //this.editDataItem = undefined;
    }

    public removeHandler({dataItem}) {
        this.editService.remove(dataItem);
        //this.editService.remove(deleteCompany);
    }

    public deleteGet(id) {
        debugger;;
        let res = this.editService.deleteCompany(id);
        res.subscribe((resp: any) => {
            debugger;;
            if (resp.Table[0].is_successful == 1) {
                this.utilModule.notify(this.utilModule.SUCCESS_TAG, resp.Table[0].message);
            } else {
                this.utilModule.notify(this.utilModule.ERROR_TAG, resp.Table[0].message);
            }
           
           this.getCompanyListData();
        })
    }

}
