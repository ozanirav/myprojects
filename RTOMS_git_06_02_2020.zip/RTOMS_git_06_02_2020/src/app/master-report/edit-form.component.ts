import { Component, Input, Output, EventEmitter, Inject, OnInit } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { CompanyListModel, StateModel } from '../models/master-report.model';
import { EditService } from '../services/master-report.service';
import { ReturnStatement } from '@angular/compiler';

@Component({
    selector: 'kendo-grid-edit-form',
    styles: [
      'input[type=text] { width: 100%; }'
    ],
    template: `
        <kendo-dialog *ngIf="active" class="custom-kendo-dialog" (close)="closeForm()">
          <kendo-dialog-titlebar>
            {{ isNew ? 'Add new product' : 'Edit product' }}
          </kendo-dialog-titlebar>

            <form novalidate [formGroup]="editForm">
                <div class="form-group p-relative" *ngIf=!(isNew)>
                    <div class="d-flex">
                        <label for="company_id" class="control-label">Company Id</label>
                        <input type="text" class="k-textbox custom-popup-text" formControlName="company_id" disabled/>
                    </div>
                </div>

                <div class="form-group p-relative">
                    <div class="d-flex">
                        <label for="company_name" class="control-label">Company Name</label>
                        <input type="text" class="k-textbox custom-popup-text" required formControlName="company_name" />
                    </div>
                </div>

                <div class="form-group p-relative">
                    <div class="d-flex">
                        <label for="address_line1" class="control-label">Address 1</label>
                        <input type="text" class="k-textbox custom-popup-text" formControlName="address_line1" />
                    </div>
                </div>

                <div class="form-group">
                    <div class="d-flex">
                        <label for="address_line2" class="control-label">Address 2</label>
                        <input type="text" class="k-textbox custom-popup-text" formControlName="address_line2" />
                    </div>   
                </div>

                <div class="form-group">
                    <div class="d-flex">
                        <label for="country_name" class="control-label">Country Name</label>
                        <select class="select-kendo" formControlName="country_name" required>
                            <option *ngFor="let country of countryList" [value]= country.country_name>{{country.country_name}}</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="d-flex">
                        <label for="state_name" class="control-label">State Name</label>
                        <select class="select-kendo" formControlName="state_name" required>
                            <option *ngFor="let state of stateList" [value]= state.state_name>{{state.state_name}}</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="d-flex">
                        <label for="pincode" class="control-label">Pincode</label>
                        <input type="text" class="k-textbox custom-popup-text" required formControlName="pincode" />
                    </div>
                </div>

                <div class="form-group">
                    <div class="d-flex">
                        <label for="company_type" class="control-label">Company Type</label>
                        <input type="text" class="k-textbox custom-popup-text" formControlName="company_type" />
                    </div>   
                </div>

                <div class="form-group">
                    <div class="d-flex">
                        <label class="control-label">Is active</label>
                        <label class="control-label k-form-field w-100">
                            <input type="checkbox" id="auth-2fa" 
                            class="k-checkbox" checked="checked" formControlName="is_active">
                            <label class="k-checkbox-label" for="auth-2fa"></label>
                        </label>
                    </div>
                </div>
                
            </form>

            <kendo-dialog-actions>
                <button class="k-button btn-basic cancel" (click)="onCancel($event)">Cancel</button>
                <button class="k-button k-primary btn-basic submit" [disabled]="!editForm.valid" (click)="onSave($event)">Save</button>
            </kendo-dialog-actions>
        </kendo-dialog>
    `
})
export class GridEditFormComponent {
    
    public active = false;
    public editForm: FormGroup = new FormGroup({
        'company_id': new FormControl(),
        'company_name': new FormControl(),
        'address_line1': new FormControl(),
        'address_line2': new FormControl(),
        'country_name': new FormControl(),
        'state_name': new FormControl(),
        'pincode': new FormControl(),
        'company_type': new FormControl(),
        'is_active': new FormControl(),
    });

    @Input() public isNew = false;

    @Input() public set model(companyListModel: CompanyListModel) {
        debugger
        this.editForm.reset(companyListModel);
        this.active = companyListModel !== undefined;
    }

    @Output() cancel: EventEmitter<any> = new EventEmitter();
    @Output() save: EventEmitter<CompanyListModel> = new EventEmitter();


    private editService: EditService;

    constructor(@Inject(EditService) editServiceFactory: any) {
        this.editService = editServiceFactory();
    }

    // stateList: Array<StateModel> = [];
    public stateList;
    public countryList;
    public finalJson;
    public updateData = [];
    public defaultItem:  StateModel = { state_id: 0, state_name: 'ko' };

    ngOnInit() {
        this.getStateListData();
        this.getCountryListData();
    }

    public getStateListData() {
        let res = this.editService.getStateListService();
        res.subscribe((resp: any) => {
            this.stateList = resp.Table;
        })
    }

    public getCountryListData() {
        let res = this.editService.getCountryListService();
        res.subscribe((resp: any) => {
            this.countryList = resp.Table;
        })
    }

    public onSave(e): void {
        this.finalJson = [];
        this.updateData = [];
        this.finalJson = [this.editForm.value]
        var st = this.stateList.filter((x) => {return x.state_name == this.finalJson[0].state_name});
        var ct = this.countryList.filter((x) => {return x.country_name == this.finalJson[0].country_name});
        e.preventDefault();
        console.log(this.isNew);
        if(this.isNew){
            this.finalJson.map(item => this.updateData.push({
                company_name: item.company_name,
                address_line1: item.address_line1,
                address_line2: item.address_line2,
                country_id: ct[0].country_id,
                state_id: st[0].state_id,
                pincode: item.pincode,
                company_type: item.company_type,
                is_active: item.is_active,
                user_id:1,
            }) );
        }else{
            this.finalJson.map(item => this.updateData.push({
                company_id: item.company_id,
                company_name: item.company_name,
                address_line1: item.address_line1,
                address_line2: item.address_line2,
                country_id: ct[0].country_id,
                state_id: st[0].state_id,
                pincode: item.pincode,
                company_type: item.company_type,
                is_active: item.is_active,
                user_id:1,
            }) );
        }
        
        this.save.emit(this.updateData[0]);
        this.active = false;
    }

    public onCancel(e): void {
        e.preventDefault();
        this.closeForm();
    }

    public closeForm(): void {
        this.active = false;
        this.cancel.emit();
    }
}
