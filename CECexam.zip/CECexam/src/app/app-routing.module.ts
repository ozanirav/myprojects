import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { QuestionMasterComponent } from './question-master/question-master.component'

const routes: Routes = [
  { path: '', component: QuestionMasterComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
